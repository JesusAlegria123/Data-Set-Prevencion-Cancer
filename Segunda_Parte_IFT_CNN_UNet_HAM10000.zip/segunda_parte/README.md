# Comparación de IFT, CNN y U-Net en HAM10000

Proyecto académico del curso **Visión Computacional** de la Universidad
Nacional de San Antonio Abad del Cusco (UNSAAC). El notebook compara
distintos enfoques de visión computacional para la **segmentación y
clasificación de lesiones cutáneas dermatoscópicas** utilizando el
conjunto de datos HAM10000.

> **Importante:** este repositorio contiene el notebook de comparación.
> Para ejecutarlo se necesita primero el resultado del notebook de
> preprocesamiento descrito más abajo. Este README documenta el diseño
> implementado; no presenta métricas finales porque estas dependen de
> ejecutar el experimento.

## Objetivo

Evaluar y comparar:

-   **IFT (Image Foresting Transform):** segmentación basada en caminos
    de costo mínimo y clasificación mediante características extraídas
    de la lesión junto con OPF.
-   **CNN:** clasificación mediante ResNet50 con pesos preentrenados en
    ImageNet y ajuste fino (*fine-tuning*).
-   **U-Net:** arquitectura codificador-decodificador utilizada para
    segmentación, clasificación y aprendizaje multitarea.

La comparación se divide en dos tareas, ya que los métodos no resuelven
exactamente el mismo problema:

1.  **Segmentación:** comparación de IFT y U-Net mediante máscaras de
    referencia.
2.  **Clasificación:** comparación de IFT + OPF, CNN ResNet50 y
    variantes de U-Net para las siete clases de HAM10000.

## Métodos implementados

### 1. IFT --- Image Foresting Transform

IFT representa la imagen como un grafo cuyos nodos son píxeles
conectados a sus vecinos. A partir de semillas, calcula caminos de costo
mínimo y forma un bosque de caminos óptimos.

Se consideran dos funciones de costo:

-   `f_max`: el costo del camino es el máximo peso de arco encontrado en
    él; se utiliza como variante tipo *watershed* por marcadores.
-   `f_sum`: acumula los pesos de los arcos y representa una distancia
    geodésica en el espacio de color.

Las semillas se generan automáticamente mediante estimación del color de
la piel, umbralización y operaciones morfológicas. Después de segmentar
se extraen **56 características** de forma, color y textura. Estas
características se utilizan para clasificación con:

-   **OPF (Optimum-Path Forest)**, basado en el concepto de bosque de
    caminos óptimos sobre las muestras.
-   **Random Forest**, como clasificador de referencia para analizar el
    aporte de las características frente al clasificador.

### 2. CNN --- ResNet50

Se utiliza ResNet50 como modelo de clasificación de siete clases. La red
parte de pesos preentrenados en ImageNet y se ajusta con los datos del
proyecto.

El entrenamiento contempla:

-   Optimizador AdamW y planificador OneCycle.
-   Pérdida de entropía cruzada ponderada para tratar el desbalance de
    clases.
-   Aumentos de datos aplicados únicamente al conjunto de entrenamiento.
-   Selección de la mejor época según F1 macro en validación.
-   Promedio de predicciones (*test-time augmentation*, TTA) para la
    imagen original y sus volteos horizontal y vertical.

### 3. U-Net

Se implementa una U-Net con codificador y decodificador, bloques
convolucionales, normalización, activaciones ReLU y conexiones *skip*
para conservar información espacial.

Se utiliza en tres variantes:

-   **U-Net de segmentación:** predice una máscara de la lesión; se
    entrena con una combinación de BCE y Dice.
-   **U-Net de clasificación:** utiliza el codificador y una cabeza
    lineal para predecir las siete clases.
-   **U-Net multitarea:** comparte el codificador y aprende
    simultáneamente segmentación y clasificación.

Las variantes supervisadas de segmentación y multitarea requieren
máscaras válidas.

## Diseño experimental

El notebook utiliza una partición común de entrenamiento, validación y
prueba. La partición se hereda del notebook de preprocesamiento y se
realiza agrupando por lesión y casi duplicados mediante
`StratifiedGroupKFold`, con el propósito de reducir la fuga de
información entre conjuntos.

Reglas del protocolo:

-   Las estadísticas de normalización se calculan únicamente con
    entrenamiento.
-   La validación se utiliza para seleccionar la mejor época y el modo
    de IFT.
-   El conjunto de prueba se reserva para la evaluación final de cada
    modelo.
-   Se mantiene la misma partición para que los modelos se evalúen sobre
    los mismos casos.

### Modelos y entradas

  ------------------------------------------------------------------------
  Método            Tarea             Entrada           Entrenamiento
  ----------------- ----------------- ----------------- ------------------
  IFT `f_max` /     Segmentación      128 × 128         Sin entrenamiento
  `f_sum`                                               supervisado;
                                                        semillas
                                                        automáticas

  IFT + OPF         Clasificación     56                OPF con muestras
                                      características   de entrenamiento

  IFT + Random      Clasificación     56                Random Forest de
  Forest                              características   referencia

  ResNet50          Clasificación     224 × 224         Ajuste fino desde
                                                        pesos ImageNet

  U-Net seg         Segmentación      128 × 128         Desde cero, BCE +
                                                        Dice

  U-Net cls         Clasificación     224 × 224         Desde cero

  U-Net multitarea  Segmentación y    224 × 224         Desde cero,
                    clasificación                       pérdidas
                                                        combinadas

  CNN + máscara IFT Clasificación     224 × 224         Ablación de
                                                        clasificación con
                                                        fondo enmascarado

  CNN desde cero    Clasificación     224 × 224         Ablación sin
                                                        preentrenamiento
  ------------------------------------------------------------------------

## Métricas de evaluación

### Clasificación

Se contemplan:

-   Exactitud (*accuracy*) y exactitud balanceada.
-   F1 macro y F1 ponderado.
-   Coeficiente de correlación de Matthews (MCC) y kappa de Cohen.
-   AUC macro y métricas por clase.
-   Sensibilidad y especificidad para melanoma y para lesiones malignas.
-   NLL y ECE para evaluar la calibración de los modelos que producen
    probabilidades.

El F1 macro y la exactitud balanceada son especialmente importantes
porque HAM10000 presenta desbalance entre clases. La exactitud global,
por sí sola, puede ocultar un rendimiento bajo en clases minoritarias.

### Segmentación

Se utilizan:

-   **Dice:** mide el solapamiento entre la máscara predicha y la
    máscara de referencia.
-   **IoU:** mide la intersección sobre la unión.
-   Precisión y *recall* por imagen.
-   Mediana y porcentaje de fallos graves (Dice menor que 0.5).

### Incertidumbre y comparación estadística

El notebook contempla *bootstrap* agrupado por lesión para estimar
intervalos de confianza y la prueba exacta de McNemar para comparaciones
pareadas entre clasificadores. Para segmentación se contempla Wilcoxon,
ya que los métodos se evalúan sobre las mismas imágenes.

## Ablaciones y explicabilidad

Se incluyen experimentos adicionales para estudiar:

1.  **Efecto de segmentar antes de clasificar:** compara ResNet50 con
    imágenes originales frente a imágenes en las que el fondo se
    reemplaza utilizando la máscara IFT.
2.  **Efecto del preentrenamiento:** compara ResNet50 preentrenada con
    la misma arquitectura entrenada desde cero.
3.  **Grad-CAM:** genera mapas de activación para inspeccionar qué
    regiones influyen en las predicciones. Es una herramienta
    cualitativa y no demuestra causalidad.

También se analizan resultados por subgrupos, acuerdo entre modelos y
complementariedad de sus predicciones.

## Requisitos

El notebook está preparado para ejecutarse en **Google Colab** y utiliza
GPU cuando está disponible.

Entre las principales bibliotecas utilizadas se encuentran:

-   Python
-   NumPy y Pandas
-   OpenCV
-   Matplotlib y Seaborn
-   scikit-learn
-   scikit-image
-   PyTorch
-   Albumentations
-   tqdm
-   numba

La primera celda instala varias dependencias. Para el experimento
completo se recomienda activar una GPU en Colab.

## Datos necesarios y ejecución

Este notebook depende de los archivos generados por un **notebook previo
de preprocesamiento**. Antes de ejecutarlo:

1.  Ejecutar el notebook de preprocesamiento de HAM10000.
2.  Exportar a Google Drive el archivo `HAM10000_preprocesado.zip` y los
    reportes `splits_y_metadatos.csv` y `train_stats.json`.
3.  Colocar los archivos en la carpeta `Mi unidad/HAM10000_procesado`,
    según las rutas configuradas en el notebook.
4.  Abrir `Comparacion_IFT_CNN_UNet_HAM10000.ipynb` en Google Colab.
5.  Activar una GPU desde **Entorno de ejecución → Cambiar tipo de
    entorno → GPU**.
6.  Revisar la configuración de rutas e hiperparámetros en la sección 0.
7.  Ejecutar las celdas en orden.

### Máscaras de referencia

Las máscaras de segmentación son opcionales para ejecutar las partes de
clasificación. Sin embargo, son necesarias para entrenar y evaluar las
variantes supervisadas de segmentación y multitarea, así como para
calcular las métricas de segmentación frente a una referencia.

En la configuración, `MASKS_SRC` debe apuntar al ZIP o carpeta de
máscaras cuando se disponga de ellas. Si se deja como `None`, el
notebook omite las partes que dependen de máscaras.

### Modo de depuración

La variable `FAST_DEBUG` permite ejecutar una prueba reducida con menos
muestras y una época. Este modo sirve para comprobar que el flujo
funciona, **no para obtener resultados experimentales finales**.

## Archivos de salida

Los resultados se exportan a la carpeta `Mi unidad/HAM10000_comparacion`
de Google Drive (o `HAM10000_comparacion_debug` en modo de depuración).
Entre los archivos generados se encuentran:

-   `clasificacion_resumen.csv`: resumen de métricas de clasificación.
-   `predicciones_test.npz`: etiquetas reales y predicciones del
    conjunto de prueba.
-   `config_ejecucion.json`: configuración utilizada en la ejecución.
-   `ckpt/`: checkpoints de los modelos.
-   `figuras/`: gráficos y visualizaciones generados.

El notebook permite reutilizar checkpoints existentes mediante
`REUSE_CKPT`, lo que ayuda a continuar después de una desconexión de
Colab.

## Limitaciones que deben considerarse

-   La CNN ResNet50 utiliza preentrenamiento en ImageNet, mientras que
    las variantes U-Net se entrenan desde cero. Por tanto, una
    diferencia de rendimiento no puede atribuirse únicamente a la
    arquitectura; la ablación de CNN desde cero ayuda a analizar este
    efecto.
-   El diseño descrito utiliza una semilla por modelo. Los intervalos de
    confianza del conjunto de prueba no representan la variabilidad
    entre distintas ejecuciones de entrenamiento.
-   Las máscaras disponibles para HAM10000 son semiautomáticas y no
    equivalen necesariamente a anotaciones manuales de referencia.
-   OPF utiliza un límite de muestras por clase para controlar el costo
    computacional.
-   La evaluación utiliza una partición concreta; se proponen varias
    semillas y validación cruzada agrupada como trabajo futuro.
-   El rendimiento sobre HAM10000 no demuestra por sí solo
    generalización a otras poblaciones, equipos o condiciones clínicas.

## Estructura del repositorio

``` text
.
├── Comparacion_IFT_CNN_UNet_HAM10000.ipynb
└── README.md
```

> El notebook requiere los datos y reportes del preprocesamiento, que no
> están incluidos en esta estructura mínima. No se deben subir imágenes
> médicas ni archivos de datos con restricciones de uso sin comprobar
> antes sus condiciones de distribución.

## Autores

**Universidad Nacional de San Antonio Abad del Cusco (UNSAAC)**\
**Curso:** Visión Computacional\
**Docente:** Hans Harley Ccacyahuillca Bejar

------------------------------------------------------------------------

*Documento de presentación del notebook de comparación IFT, CNN y U-Net
sobre HAM10000.*
