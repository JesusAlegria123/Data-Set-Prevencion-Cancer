
## Segunda parte: comparación de IFT, CNN y U-Net

Como continuación del preprocesamiento de HAM10000, esta segunda parte compara los enfoques IFT, CNN (ResNet50) y U-Net para la segmentación y clasificación de lesiones cutáneas.

- [Documentación de la segunda parte](segunda_parte/README.md)
- [Notebook de comparación IFT, CNN y U-Net](segunda_parte/Comparacion_IFT_CNN_UNet_HAM10000.ipynb)

> **Orden de ejecución:** primero ejecuta `notebooks/HAM10000_Preprocesamiento_Colab.ipynb` y luego el notebook de `segunda_parte`. El segundo depende de los archivos preprocesados y reportes que genera el primero en Google Drive.
